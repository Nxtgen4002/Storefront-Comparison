STOREFRONT SECURITY LAB

Requirements:
- Python 3.10 or newer
- Flask

Run on Windows:
1. Extract the ZIP file.
2. Open Command Prompt in the extracted storefront_comparison folder.
3. Create a virtual environment:
   py -m venv venv
4. Activate it:
   venv\Scripts\activate
5. Install dependencies:
   pip install -r requirements.txt
6. Start the application:
   python app.py
7. Open:
   http://127.0.0.1:5000

Demo accounts:
- alice / alice123
- bob / bob123

Pages:
- /legacy: server-rendered storefront
- /modern: JavaScript frontend using JSON API endpoints
- /comparison: comparison table and test plan

The SQLite database is created automatically on the first run.

Security lab notes:
- The legacy order detail route intentionally demonstrates a missing object-ownership check.
- The modern API checks order ownership.
- Both models use simple plaintext demo passwords to keep the project easy to inspect. This is not suitable for real deployment. A production version should use password hashing, CSRF protection, secure cookie settings, rate limiting, and proper secret management.
- Keep this project on localhost. Use dummy accounts and data only.
