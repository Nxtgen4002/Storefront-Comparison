from flask import Flask, request, session, redirect, url_for, jsonify, render_template, abort
import sqlite3
import os
from functools import wraps

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "local-demo-key-change-before-deployment")
DB_PATH = os.path.join(os.path.dirname(__file__), "storefront.db")

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = db()
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        description TEXT NOT NULL,
        price REAL NOT NULL
    );
    CREATE TABLE IF NOT EXISTS orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        product_id INTEGER NOT NULL,
        quantity INTEGER NOT NULL,
        total REAL NOT NULL,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(user_id) REFERENCES users(id),
        FOREIGN KEY(product_id) REFERENCES products(id)
    );
    """)
    if conn.execute("SELECT COUNT(*) FROM users").fetchone()[0] == 0:
        conn.executemany("INSERT INTO users(username,password) VALUES(?,?)", [
            ("alice", "alice123"),
            ("bob", "bob123")
        ])
    if conn.execute("SELECT COUNT(*) FROM products").fetchone()[0] == 0:
        conn.executemany("INSERT INTO products(name,description,price) VALUES(?,?,?)", [
            ("Security Handbook", "A practical introduction to web security.", 499.00),
            ("Mechanical Keyboard", "Compact keyboard for everyday work.", 2499.00),
            ("USB-C Hub", "Multi-port hub for laptops.", 1299.00),
            ("Privacy Webcam Cover", "Simple sliding cover for a webcam.", 199.00)
        ])
    conn.commit()
    conn.close()

def current_user():
    return session.get("user_id")

def login_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if not current_user():
            if request.path.startswith("/api/"):
                return jsonify({"error": "Login required"}), 401
            return redirect(url_for("legacy_login"))
        return fn(*args, **kwargs)
    return wrapped

def products():
    conn = db()
    rows = conn.execute("SELECT * FROM products ORDER BY id").fetchall()
    conn.close()
    return rows

@app.route("/")
def home():
    return render_template("home.html")

@app.route("/legacy")
def legacy_store():
    conn = db()
    rows = conn.execute("SELECT * FROM products ORDER BY id").fetchall()
    conn.close()
    return render_template("legacy_store.html", products=rows, username=session.get("username"))

@app.route("/legacy/login", methods=["GET", "POST"])
def legacy_login():
    error = None
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        conn = db()
        user = conn.execute("SELECT * FROM users WHERE username=? AND password=?", (username, password)).fetchone()
        conn.close()
        if user:
            session.clear()
            session["user_id"] = user["id"]
            session["username"] = user["username"]
            return redirect(url_for("legacy_store"))
        error = "Invalid username or password"
    return render_template("login.html", error=error, mode="legacy")

@app.route("/modern")
def modern_store():
    return render_template("modern_store.html", username=session.get("username"))

@app.route("/modern/login", methods=["GET", "POST"])
def modern_login():
    error = None
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        conn = db()
        user = conn.execute("SELECT * FROM users WHERE username=? AND password=?", (username, password)).fetchone()
        conn.close()
        if user:
            session.clear()
            session["user_id"] = user["id"]
            session["username"] = user["username"]
            return redirect(url_for("modern_store"))
        error = "Invalid username or password"
    return render_template("login.html", error=error, mode="modern")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("home"))

@app.route("/legacy/order/<int:order_id>")
@login_required
def legacy_order(order_id):
    conn = db()
    order = conn.execute("""
        SELECT orders.*, products.name AS product_name, users.username
        FROM orders
        JOIN products ON products.id=orders.product_id
        JOIN users ON users.id=orders.user_id
        WHERE orders.id=?
    """, (order_id,)).fetchone()
    conn.close()
    if not order:
        abort(404)
    return render_template("order.html", order=order, mode="legacy", own=order["user_id"] == current_user())

@app.route("/legacy/checkout", methods=["POST"])
@login_required
def legacy_checkout():
    try:
        product_id = int(request.form.get("product_id", "0"))
        quantity = int(request.form.get("quantity", "1"))
    except ValueError:
        abort(400)
    if quantity < 1 or quantity > 10:
        abort(400)
    conn = db()
    product = conn.execute("SELECT * FROM products WHERE id=?", (product_id,)).fetchone()
    if not product:
        conn.close()
        abort(404)
    total = product["price"] * quantity
    cur = conn.execute("INSERT INTO orders(user_id,product_id,quantity,total) VALUES(?,?,?,?)",
                       (current_user(), product_id, quantity, total))
    order_id = cur.lastrowid
    conn.commit()
    conn.close()
    return redirect(url_for("legacy_order", order_id=order_id))

@app.route("/api/products")
def api_products():
    return jsonify([dict(p) for p in products()])

@app.route("/api/login", methods=["POST"])
def api_login():
    data = request.get_json(silent=True) or {}
    username = str(data.get("username", "")).strip()
    password = str(data.get("password", ""))
    conn = db()
    user = conn.execute("SELECT * FROM users WHERE username=? AND password=?", (username, password)).fetchone()
    conn.close()
    if not user:
        return jsonify({"error": "Invalid username or password"}), 401
    session.clear()
    session["user_id"] = user["id"]
    session["username"] = user["username"]
    return jsonify({"message": "Logged in", "username": user["username"]})

@app.route("/api/logout", methods=["POST"])
def api_logout():
    session.clear()
    return jsonify({"message": "Logged out"})

@app.route("/api/checkout", methods=["POST"])
@login_required
def api_checkout():
    data = request.get_json(silent=True) or {}
    try:
        product_id = int(data.get("product_id", 0))
        quantity = int(data.get("quantity", 1))
    except (TypeError, ValueError):
        return jsonify({"error": "Invalid product or quantity"}), 400
    if quantity < 1 or quantity > 10:
        return jsonify({"error": "Quantity must be between 1 and 10"}), 400
    conn = db()
    product = conn.execute("SELECT * FROM products WHERE id=?", (product_id,)).fetchone()
    if not product:
        conn.close()
        return jsonify({"error": "Product not found"}), 404
    total = product["price"] * quantity
    cur = conn.execute("INSERT INTO orders(user_id,product_id,quantity,total) VALUES(?,?,?,?)",
                       (current_user(), product_id, quantity, total))
    order_id = cur.lastrowid
    conn.commit()
    conn.close()
    return jsonify({"message": "Order created", "order_id": order_id, "total": total})

@app.route("/api/orders/<int:order_id>")
@login_required
def api_order(order_id):
    conn = db()
    order = conn.execute("""
        SELECT orders.*, products.name AS product_name
        FROM orders JOIN products ON products.id=orders.product_id
        WHERE orders.id=? AND orders.user_id=?
    """, (order_id, current_user())).fetchone()
    conn.close()
    if not order:
        return jsonify({"error": "Order not found"}), 404
    return jsonify(dict(order))

@app.route("/api/my-orders")
@login_required
def api_my_orders():
    conn = db()
    rows = conn.execute("""
        SELECT orders.*, products.name AS product_name
        FROM orders JOIN products ON products.id=orders.product_id
        WHERE orders.user_id=? ORDER BY orders.id DESC
    """, (current_user(),)).fetchall()
    conn.close()
    return jsonify([dict(row) for row in rows])

@app.route("/comparison")
def comparison():
    return render_template("comparison.html")

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
