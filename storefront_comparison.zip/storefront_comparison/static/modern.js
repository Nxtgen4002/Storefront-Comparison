const productRoot = document.getElementById("products");
const statusRoot = document.getElementById("status");
const ordersRoot = document.getElementById("orders-list");

function setStatus(message, isError = false) {
    if (!statusRoot) return;
    statusRoot.textContent = message;
    statusRoot.className = isError ? "status error" : "status";
}

async function loadProducts() {
    if (!productRoot) return;
    try {
        const response = await fetch("/api/products");
        const items = await response.json();
        productRoot.replaceChildren();
        items.forEach((item) => {
            const card = document.createElement("article");
            card.className = "product-card";
            const art = document.createElement("div");
            art.className = "product-art";
            art.textContent = item.name.slice(0, 1);
            const body = document.createElement("div");
            body.className = "product-body";
            const title = document.createElement("h2");
            title.textContent = item.name;
            const description = document.createElement("p");
            description.textContent = item.description;
            const price = document.createElement("p");
            price.className = "price";
            price.textContent = `₹${Number(item.price).toFixed(2)}`;
            body.append(title, description, price);
            if (document.querySelector("#auth-area strong")) {
                const form = document.createElement("form");
                form.className = "buy-form";
                const label = document.createElement("label");
                label.textContent = "Quantity ";
                const quantity = document.createElement("input");
                quantity.type = "number";
                quantity.min = "1";
                quantity.max = "10";
                quantity.value = "1";
                quantity.required = true;
                label.appendChild(quantity);
                const button = document.createElement("button");
                button.type = "submit";
                button.className = "button";
                button.textContent = "Place test order";
                form.append(label, button);
                form.addEventListener("submit", async (event) => {
                    event.preventDefault();
                    const result = await fetch("/api/checkout", {
                        method: "POST",
                        headers: {"Content-Type": "application/json"},
                        body: JSON.stringify({product_id: item.id, quantity: Number(quantity.value)})
                    });
                    const data = await result.json();
                    if (!result.ok) {
                        setStatus(data.error || "Order failed", true);
                        return;
                    }
                    setStatus(`Order #${data.order_id} created. Total: ₹${Number(data.total).toFixed(2)}`);
                });
                body.appendChild(form);
            } else {
                const login = document.createElement("a");
                login.href = "/modern/login";
                login.textContent = "Login to order";
                body.appendChild(login);
            }
            card.append(art, body);
            productRoot.appendChild(card);
        });
    } catch {
        setStatus("Could not load products.", true);
    }
}

const ordersButton = document.getElementById("orders-button");
if (ordersButton) {
    ordersButton.addEventListener("click", async () => {
        const response = await fetch("/api/my-orders");
        const data = await response.json();
        if (!response.ok) {
            setStatus(data.error || "Could not load orders.", true);
            return;
        }
        ordersRoot.replaceChildren();
        if (data.length === 0) {
            ordersRoot.textContent = "No orders yet.";
            return;
        }
        const list = document.createElement("ul");
        data.forEach((order) => {
            const item = document.createElement("li");
            item.textContent = `Order #${order.id}: ${order.product_name}, quantity ${order.quantity}, total ₹${Number(order.total).toFixed(2)}`;
            list.appendChild(item);
        });
        ordersRoot.appendChild(list);
    });
}

const logoutButton = document.getElementById("logout-button");
if (logoutButton) {
    logoutButton.addEventListener("click", async () => {
        await fetch("/api/logout", {method: "POST"});
        window.location.href = "/";
    });
}

loadProducts();
